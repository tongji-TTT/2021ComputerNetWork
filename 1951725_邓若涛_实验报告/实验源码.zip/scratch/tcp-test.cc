#include <string>
#include <unistd.h>
#include<stdio.h>
#include <iostream>
#include "ns3/core-module.h"
#include "ns3/applications-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/traffic-control-module.h"
#include "ns3/tcp-client-module.h"
using namespace ns3;
using namespace std;

NS_LOG_COMPONENT_DEFINE ("TcpTest");
static const double startTime=0;
static const double simDuration= 300.0;
#define DEFAULT_PACKET_SIZE 1500
static NodeContainer BuildExampleTopo (uint32_t bps,
                                       uint32_t msDelay,
                                       uint32_t msQdelay,
                                       bool enable_random_loss=false)
{
    NodeContainer nodes;
//两个节点
    nodes.Create (2);
// pointtopoint channel
    PointToPointHelper pointToPoint;
//设置速率
    pointToPoint.SetDeviceAttribute ("DataRate", DataRateValue  (DataRate (bps)));
 //设置延迟  
 pointToPoint.SetChannelAttribute ("Delay", TimeValue (MilliSeconds (msDelay)));
    auto bufSize = std::max<uint32_t> (DEFAULT_PACKET_SIZE, bps * msQdelay / 8000);
//包的个数   
 int packets=bufSize/DEFAULT_PACKET_SIZE;
    NS_LOG_INFO("buffer packet "<<packets);
//传输队列
    pointToPoint.SetQueue ("ns3::DropTailQueue",
                           "MaxSize", StringValue (std::to_string(1)+"p"));
 // 用于管理网络设备
    NetDeviceContainer devices = pointToPoint.Install (nodes);
  //此帮助程序启用 pcap 和 ascii 跟踪与节点关联的 Internet 堆栈中的事件
    InternetStackHelper stack;
    stack.Install (nodes);

//流量控制的helper
    TrafficControlHelper pfifoHelper;
    //实现 FIFO（先进先出）策略的简单队列磁盘。
    uint16_t handle = pfifoHelper.SetRootQueueDisc ("ns3::FifoQueueDisc", "MaxSize", StringValue (std::to_string(packets)+"p"));
    //增加到网络队列上
    pfifoHelper.AddInternalQueues (handle, 1, "ns3::DropTailQueue", "MaxSize",StringValue (std::to_string(packets)+"p"));
    //添加到服务上
    pfifoHelper.Install(devices);
    //Ipv4地址分配
    Ipv4AddressHelper address;
    ////设置了一个ip网络号和子网掩码，意味着这个网络的ip地址从10.1.1.0~10.1.1.255.
    std::string nodeip="10.1.1.0";
    address.SetBase (nodeip.c_str(), "255.255.255.0");
    //实现ip地址的分配，devices中的device们，将按递增顺序获得ip地址和子网掩码，从10.1.1.1到10.1.1.2
    address.Assign (devices);

    if(enable_random_loss){
        std::string errorModelType = "ns3::RateErrorModel";
        ObjectFactory factory;
        factory.SetTypeId (errorModelType);
        Ptr<ErrorModel> em = factory.Create<ErrorModel> ();
        devices.Get (1)->SetAttribute ("ReceiveErrorModel", PointerValue (em));
    }
    return nodes;
}
// ./waf --run "scratch/tcp-test --cc=bbr --folder=bbr"
int main(int argc, char *argv[])
{
    //打印指定LOG组件信息
    LogComponentEnable("TcpTest", LOG_LEVEL_ALL);
    LogComponentEnable("TcpClient", LOG_LEVEL_ALL);
    LogComponentEnable("TcpBbr", LOG_LEVEL_ALL);

    std::string cc("bbr2");
    std::string folder_name("default");

    CommandLine cmd;
    //通过命令决定cc和folder的值
    cmd.AddValue ("cc", "congestion algorithm",cc);
    cmd.AddValue ("folder", "folder name to collect data", folder_name);
    cmd.Parse (argc, argv);
    //TCP一次传输发送的最大数据段长度
    uint32_t kMaxmiumSegmentSize=1400;
    //发送缓冲区大小
    Config::SetDefault("ns3::TcpSocket::SndBufSize", UintegerValue(200*kMaxmiumSegmentSize));
    //接受缓冲区大小
    Config::SetDefault("ns3::TcpSocket::RcvBufSize", UintegerValue(200*kMaxmiumSegmentSize));
    Config::SetDefault("ns3::TcpSocket::SegmentSize",UintegerValue(kMaxmiumSegmentSize));
    //查看cc是否是我们定义的合法算法
    if(0==cc.compare("reno")||0==cc.compare("bic")||0==cc.compare("cubic")||
      0==cc.compare("bbr")||0==cc.compare("copa")){}
    else{
        NS_ASSERT_MSG(0,"please input correct cc");//错误，请输入合法的cc
    }
    std::string trace_folder;
    
    {
        //将结果放入traces中追踪
        char buf[FILENAME_MAX];
        std::string trace_path=std::string (getcwd(buf, FILENAME_MAX))+"/traces/";
        trace_folder=trace_path+folder_name+"/";
        //在traces中创建文件夹
        MakePath(trace_folder);
        TcpBbrDebug::SetTraceFolder(trace_folder.c_str());
        //设置监听器
        TcpTracer::SetTraceFolder(trace_folder.c_str());
    }
    //自定义比特率
    uint32_t link_bw=6000000;
    uint32_t link_owd=50;
    uint32_t q_delay=200;
    NodeContainer topo;
    //生成配置
    topo=BuildExampleTopo(link_bw,link_owd,q_delay);
    //提取节点的指针
    Ptr<Node> h1=topo.Get(0);
    Ptr<Node> h2=topo.Get(1);

    //for utility
    TcpTracer::SetExperimentInfo(3,link_bw);
    //for loss rate
    TcpTracer::SetLossRateFlag(true);

    uint16_t serv_port = 5000;
    //install server on h2
    Address tcp_sink_addr;
    {
        Ptr<Ipv4> ipv4 = h2->GetObject<Ipv4> ();
        Ipv4Address serv_ip= ipv4->GetAddress (1, 0).GetLocal();
        //用于实现套接字，他可以是IP地址＋端口号，也可以是 主机名+端口号
        InetSocketAddress socket_addr=InetSocketAddress{serv_ip,serv_port};
        tcp_sink_addr=socket_addr;
        Ptr<TcpServer> server=CreateObject<TcpServer>(tcp_sink_addr);
        h2->AddApplication(server);
        server->SetStartTime (Seconds (0.0));
    }

    uint64_t totalTxBytes = 40000*1500;
    //构建了TCP的client并根据cc算法的种类来进行运输，终止时间一定，开始时间不同
    {
        Ptr<TcpClient>  client= CreateObject<TcpClient> (totalTxBytes,TcpClient::E_TRACE_RTT|TcpClient::E_TRACE_INFLIGHT|TcpClient::E_TRACE_RATE);
        h1->AddApplication(client);
        client->ConfigurePeer(tcp_sink_addr);
        client->SetCongestionAlgo(cc);
        client->SetStartTime (Seconds (startTime));
        //停止时间在开头有定义
        client->SetStopTime (Seconds (simDuration));
    }
    {
        Ptr<TcpClient>  client= CreateObject<TcpClient> (totalTxBytes,TcpClient::E_TRACE_RTT|TcpClient::E_TRACE_INFLIGHT|TcpClient::E_TRACE_RATE);
        h1->AddApplication(client);
        client->ConfigurePeer(tcp_sink_addr);
        client->SetCongestionAlgo(cc);
        client->SetStartTime (Seconds (startTime+20));
        client->SetStopTime (Seconds (simDuration));
    }
    {
        Ptr<TcpClient>  client= CreateObject<TcpClient> (totalTxBytes,TcpClient::E_TRACE_RTT|TcpClient::E_TRACE_INFLIGHT|TcpClient::E_TRACE_RATE);
        h1->AddApplication(client);
        client->ConfigurePeer(tcp_sink_addr);
        client->SetCongestionAlgo(cc);
        client->SetStartTime (Seconds (startTime+50));
        client->SetStopTime (Seconds (simDuration));
    }
    //模拟器操作
    Simulator::Stop (Seconds (simDuration+10.0));
    Simulator::Run ();
    Simulator::Destroy ();
    return 0;
    
}
